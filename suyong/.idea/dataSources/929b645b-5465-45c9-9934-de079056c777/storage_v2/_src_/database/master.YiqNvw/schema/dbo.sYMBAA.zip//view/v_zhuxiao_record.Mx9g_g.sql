create view v_zhuxiao_record
as
select Id_num  账号,  Zhuxia_time 注销时间,  Zhuxia_reas 注销事由,  Id_pop 经办人
from zhuxiao_record
go

