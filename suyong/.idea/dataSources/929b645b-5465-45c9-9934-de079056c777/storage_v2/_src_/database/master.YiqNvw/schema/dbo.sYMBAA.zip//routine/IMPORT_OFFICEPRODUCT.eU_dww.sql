


--用品登记导入
CREATE PROCEDURE  [dbo].[IMPORT_OFFICEPRODUCT]  
AS 
   -- 开始定义变量、游标 --
   BEGIN

      DECLARE
         @lc$PRODUCTSDETAILSID varchar(33), 
         @lc$PRODUCTCODE varchar(120), 
         @lc$CREATED varchar(12), 
         @lc$WAREHOUSEID varchar(120), 
         @lc$SUPPLIERS varchar(120), 
         @lc$PURCHASEDATE varchar(32), 
         @lc$PURCHASE varchar(32), 
         @lc$LNVENTORY numeric(38, 0), 
         @lc$RRICE numeric(10, 3), 
         @lc$TOTALMONEY numeric(11, 3), 
         @lc$REMARK varchar(255), 
         @lc$COMM_APPID varchar(50)

      DECLARE
          sur CURSOR LOCAL FORWARD_ONLY FOR 
            SELECT 
               TBL_OFFICE_USAGE_PRODUCTS_TEMP.PRODUCTSDETAILSID, 
               TBL_OFFICE_USAGE_PRODUCTS_TEMP.PRODUCTCODE, 
               TBL_OFFICE_USAGE_PRODUCTS_TEMP.CREATED, 
               TBL_OFFICE_USAGE_PRODUCTS_TEMP.WAREHOUSEID, 
               TBL_OFFICE_USAGE_PRODUCTS_TEMP.SUPPLIERS, 
               TBL_OFFICE_USAGE_PRODUCTS_TEMP.PURCHASEDATE, 
               TBL_OFFICE_USAGE_PRODUCTS_TEMP.PURCHASE, 
               TBL_OFFICE_USAGE_PRODUCTS_TEMP.LNVENTORY, 
               TBL_OFFICE_USAGE_PRODUCTS_TEMP.RRICE, 
               TBL_OFFICE_USAGE_PRODUCTS_TEMP.TOTALMONEY, 
               TBL_OFFICE_USAGE_PRODUCTS_TEMP.REMARK, 
               TBL_OFFICE_USAGE_PRODUCTS_TEMP.COMM_APPID
            FROM dbo.TBL_OFFICE_USAGE_PRODUCTS_TEMP

      OPEN sur
      -- 循环插入用品登记信息 --
      WHILE 1 = 1
      
         BEGIN

            FETCH sur
                INTO 
                  @lc$PRODUCTSDETAILSID, 
                  @lc$PRODUCTCODE, 
                  @lc$CREATED, 
                  @lc$WAREHOUSEID, 
                  @lc$SUPPLIERS, 
                  @lc$PURCHASEDATE, 
                  @lc$PURCHASE, 
                  @lc$LNVENTORY, 
                  @lc$RRICE, 
                  @lc$TOTALMONEY, 
                  @lc$REMARK, 
                  @lc$COMM_APPID

            IF @@FETCH_STATUS = -1
               BREAK

            INSERT dbo.TBL_OFFICE_USAGE_PRODUCTS(
               PRODUCTSDETAILSID, 
               PRODUCTSREGISTRATIONID, 
               USER_ID, 
               SUPPLIERS, 
               PURCHASEDATE, 
               PURCHASE, 
               STORAGENUMBER, 
               LNVENTORY, 
               ORGANIZATIONALLEVELCODE, 
               AGENCYCODE, 
               WAREHOUSEID, 
               REMARK, 
               RRICE, 
               BATCHLNVENTORY, 
               BATCHNO)
               VALUES (
                  @lc$PRODUCTSDETAILSID, 
                     (
                        SELECT top 1  t.PRODUCTSREGISTRATIONID
                        FROM dbo.TBL_OFFICE_USAGE_STOCK  AS t
                        WHERE t.PRODUCTSCODE = @lc$PRODUCTCODE and  CREATELOGO='0'
                     ), 
                     (
                        SELECT top 1 u.USER_ID
                        FROM dbo.TBL_SYS_USER  AS u
                        WHERE u.USER_NAME = @lc$CREATED AND COMM_RECORD_IDENTY IN (0,1)
                     ), 
                  @lc$SUPPLIERS, 
                  @lc$PURCHASEDATE, 
                  @lc$CREATED, 
                  @lc$LNVENTORY, 
                  @lc$LNVENTORY, 
                  
                     (
                        SELECT top 1 u.COMM_ORG_LEVEL
                        FROM dbo.TBL_SYS_USER  AS u
                        WHERE u.USER_NAME = @lc$CREATED  AND COMM_RECORD_IDENTY IN (0,1)
                     ), 
                  
                     (
                        SELECT top 1 u.COMM_ORG_IDENTY
                        FROM dbo.TBL_SYS_USER  AS u
                        WHERE u.USER_NAME = @lc$CREATED  AND COMM_RECORD_IDENTY IN (0,1)
                     ), 
                  
                     (
                        SELECT  w.WAREHOUSEID
                        FROM dbo.TBL_OFFICE_USAGE_WAREHOUSE  AS w
                        where w.warehousename=@lc$WAREHOUSEID
                     ), 
                  @lc$REMARK, 
                  @lc$RRICE, 
                  @lc$LNVENTORY, 
                  '1');     
           
				 -- 获取是否存在用品登记、仓库、类别关联表信息，如果存在则更新，反之新增 --
            DECLARE @nOutput Bigint
            SELECT @nOutput = count(*)
            FROM dbo.TBL_OFFICE_USAGE_WAR_PRO  AS d
            WHERE d.WAREHOUSEID=(
                     SELECT w.WAREHOUSEID
                     FROM dbo.TBL_OFFICE_USAGE_WAREHOUSE  AS w
                     where w.warehousename=@lc$WAREHOUSEID
                  ) AND d.PRODUCTSREGISTRATIONID = (
                     SELECT t.PRODUCTSREGISTRATIONID
                     FROM dbo.TBL_OFFICE_USAGE_STOCK  AS t
                     WHERE t.PRODUCTSCODE = @lc$PRODUCTCODE and  t.CREATELOGO='0'
                  );
          IF (@nOutput=0 or @nOutput is null or @nOutput='')
							INSERT dbo.TBL_OFFICE_USAGE_WAR_PRO(WAREHOUSEID, PRODUCTSREGISTRATIONID, NUMBERS, BATCHNUMBER)
								 VALUES (
									(
									 SELECT w.WAREHOUSEID
									 FROM dbo.TBL_OFFICE_USAGE_WAREHOUSE  AS w
									 where w.warehousename=@lc$WAREHOUSEID
									), 
									(
									 SELECT t.PRODUCTSREGISTRATIONID
									 FROM dbo.TBL_OFFICE_USAGE_STOCK  AS t
									 WHERE t.PRODUCTSCODE = @lc$PRODUCTCODE and  t.CREATELOGO='0'
									), @lc$LNVENTORY, ISNULL(CAST(@lc$LNVENTORY AS nvarchar(max)), '') + ',') 
					 ELSE
					    UPDATE dbo.TBL_OFFICE_USAGE_WAR_PRO 
								 SET batchnumber =
										 (batchnumber + convert(varchar(50),@lc$LNVENTORY) + ','),
										 numbers    =
										 (
											cast( ISNULL(NUMBERS,0) as int) +  cast( ISNULL(@lc$LNVENTORY,0) as int) 
										 )
									WHERE WAREHOUSEID =
										 (SELECT w.WAREHOUSEID
												FROM TBL_OFFICE_USAGE_WAREHOUSE w
											 where w.warehousename = @lc$WAREHOUSEID)
								 AND PRODUCTSREGISTRATIONID =
										 (SELECT t.PRODUCTSREGISTRATIONID
												FROM TBL_OFFICE_USAGE_STOCK t
											 WHERE t.PRODUCTSCODE = @lc$PRODUCTCODE and t.CREATELOGO!=3)
			END
      CLOSE sur

      DEALLOCATE sur


   END

go

