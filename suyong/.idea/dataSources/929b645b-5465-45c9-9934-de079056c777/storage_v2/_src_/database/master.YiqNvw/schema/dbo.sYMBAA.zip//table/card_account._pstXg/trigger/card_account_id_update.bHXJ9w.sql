create trigger card_account_id_update
on card_account
    for update
as
    declare @oldid int,@newid int ,@user varchar(50);
    --更新前的数据
    select @oldid =  card_account_id from deleted;
	select @newid =  card_account_id from inserted;
	select @user =  card_account_user from inserted;
	print @oldid;
	print @newid;
	if (@oldid!=@newid and @oldid!=0)
		begin
		print '插入补办记录成功2！';
		--更新后的数据
			insert reward_card(reward_card_user,reward_card_oldid,reward_card_newid) values(@user ,@oldid,@newid)
		end
	else
		print '插入补办记录失败2！';
go

