create view czjl as
select  charmon_user 账号,charmon_money 金额,charmon_time 时间,charmon_opt 经办人 from charmon
go

