create view fkjl as
select pay_book_user 账号,pay_book_type 事由,pay_book_day 逾期,pay_book_money 金额,pay_book_status 缴纳,pay_book_time 时间 from pay_book
go

