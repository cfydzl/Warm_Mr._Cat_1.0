create  view v_expense_manage as(
select a.user_id as userId ,a.user_show_name as userName , i.DEPT_ID as deptId,i.COMM_ORG_IDENTY as commOrgIdenty, i.comm_org_level,                               
       (                                                                                                	
           select isnull(sum(b.amount),0)                                                                  	
               from TBL_EXPENSE_BORROW_BACK  b                                                          	
               where b.status = '3' and b.borrow_userid = a.user_id and b.comm_org_identy=i.comm_org_identy                                      	
		     and b.kx_type ='1'                                                                               
       ) as borrowMoney,                                                                                	
       (                                                                                                	
          select isnull(sum(b.amount),0)                                                                   	
               from TBL_EXPENSE_BORROW_BACK  b                                                          	
               where b.status = '3'  and b.borrow_userid = a.user_id and b.comm_org_identy=i.comm_org_identy                                       	
		     and b.kx_type ='2' and b.comm_record_identy ='1' and (b.back_type is null or b.back_type='1')                                                                          
       ) as backMoney,                                                                                  	
     (         		                                                                                       	
	  select isnull(sum(k.REIMBUR_AMOUNT),0)                                                                   
		from TBL_EXPENSE_REIMBUR c,TBL_EXPENSE_COMMREIMBUR_DESC k                                           
		where  c.STATUS = '3'  and c.REIMBUR_USERID = a.user_id                                                
			and c.IS_TRAVEL = '1'                                                                             
			and c.REIMBUR_ID = k.REIMBUR_ID
			and c.reimbur_dept_id=i.dept_id
       ) as expenseReimburMoney,                                                                        	
     (      	                                                                                          	
	  select isnull(sum(d.AMOUNT),0)                                                                        	 
		from TBL_EXPENSE_REIMBUR c,TBL_EXPENSE_TRAVELREIMBUR_DESC d                                        	 
		where  c.STATUS = '3'  and c.REIMBUR_USERID = a.user_id                                               	 
			and c.IS_TRAVEL = '2'                                                                             
			and c.REIMBUR_ID = d.REIMBUR_ID                                                                  
			and d.ZF_TYPE = '2'
            and c.reimbur_dept_id=i.dept_id			
       ) as travelReimburMoney,                                                                         	
     (      	                                                                                          	
	 select isnull(sum(f.PAY_AMOUNT),0)                                                                      	
		from TBL_EXPENSE_XZFK e, TBL_EXPENSE_XZFK_DESC f                                                    
		where e.STATUS = '3'  and e.USER_ID = a.user_id                                                        
			and e.XZFK_ID = f.XZFK_ID
            and e.comm_org_identy=i.comm_org_identy			
       ) as xzPayMoney,                                                                                 	
     (                                                                                               		
	 select isnull(sum(h.SHARE_AMOUNT),0)                                                                    	
		from TBL_EXPENSE_SHARE g, TBL_EXPENSE_SHARE_DESC h                                                  
		where g.STATUS = '3' and g.USER_ID = a.user_id                                                        
			and g.SHARE_ID = h.SHARE_ID
            and g.comm_org_identy=i.comm_org_identy			
       ) as expenseShareMoney                                                                           	
 from tbl_sys_user_department a left join tbl_sys_department i on a.department_id=i.dept_id
 );
go

