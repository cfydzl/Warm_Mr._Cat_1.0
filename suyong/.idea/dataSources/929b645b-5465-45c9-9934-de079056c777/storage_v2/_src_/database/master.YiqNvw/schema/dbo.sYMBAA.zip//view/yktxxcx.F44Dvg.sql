create view yktxxcx as
select school_card_id 卡号,school_card_statu 卡状态  from school_card
go

