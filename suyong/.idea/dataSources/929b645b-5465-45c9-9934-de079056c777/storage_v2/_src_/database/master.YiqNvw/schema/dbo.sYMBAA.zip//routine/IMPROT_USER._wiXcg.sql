
--用户导入存储过程lsl
------------------------------------用户导入start------------------------------------------------------
CREATE PROCEDURE [dbo].[IMPROT_USER]  
   @nOutput int  OUTPUT,
   @deptIdParam varchar(max),
   @deptNameParam varchar(max)
AS 
   BEGIN
	  --部门为空，设置默认部门
	  update tbl_sys_user_temp set DUTY_DEPT_ID = (select dept_tier from tbl_sys_department where dept_id=@deptIdParam ) where DUTY_DEPT_ID is null;
	  commit;
  
	  --修改POST_NAME
	  update tbl_sys_user_temp set DUTY_DEPT_ID=replace(DUTY_DEPT_ID,'/','-');
	  commit;
    
      SET @nOutput = NULL

      DECLARE
         @usernum int, 
         @deptId varchar(40)

      DECLARE
         @row_userImport$USER_ID varchar(32), 
         @row_userImport$DEPT_ID varchar(2000), 
         @row_userImport$USER_ACCOUNTS varchar(20), 
         @row_userImport$USER_CODE varchar(100), 
         @row_userImport$USER_NAME varchar(40), 
         @row_userImport$USER_NAME_SPELL varchar(600), 
         @row_userImport$USER_SEX varchar(32), 
         @row_userImport$DICT_ID varchar(32), 
         @row_userImport$THEM_ID varchar(32), 
         @row_userImport$USER_STANDBY_NAME varchar(40), 
         @row_userImport$USER_COMP_IP varchar(128), 
         @row_userImport$USER_LEADER_FLAG varchar(1), 
         @row_userImport$USER_PASSWORD varchar(128), 
         @row_userImport$USER_EFFECT_DATE datetime2(0), 
         @row_userImport$USER_CANCEL_DATE datetime2(0), 
         @row_userImport$USER_PHONE varchar(40), 
         @row_userImport$USER_MOBILE varchar(40), 
         @row_userImport$USER_MOBILE_IS_HIDE varchar(1), 
         @row_userImport$USER_QQ varchar(32), 
         @row_userImport$USER_MSN varchar(255), 
         @row_userImport$USER_EMAIL varchar(255), 
         @row_userImport$USER_IS_ONLINE varchar(1), 
         /*
         *   SSMA warning messages:
         *   O2SS0356: Conversion from NUMBER datatype can cause data loss.
         */

         @row_userImport$SORT_ORDER float(53), 
         @row_userImport$USER_TYPE_ID varchar(32), 
         @row_userImport$USER_REMARK varchar(600), 
         @row_userImport$COMM_CREATOR varchar(32), 
         @row_userImport$COMM_CREATE_TIME char(19), 
         @row_userImport$COMM_RECORD_IDENTY numeric(38, 0), 
         @row_userImport$COMM_EDITION_ID varchar(32), 
         @row_userImport$COMM_EDITION_NO numeric(38, 0), 
         @row_userImport$COMM_BUINESS_ORDER numeric(38, 0), 
         @row_userImport$COMM_ORG_LEVEL varchar(60), 
         @row_userImport$COMM_ORG_IDENTY varchar(60), 
         @row_userImport$COMM_CHANGE_NOTICE varchar(60), 
         @row_userImport$BLANK0 varchar(100), 
         @row_userImport$BLANK1 varchar(100), 
         @row_userImport$BLANK2 varchar(100), 
         @row_userImport$PAY_PASSWORD varchar(100), 
         @row_userImport$USER_PX numeric(38, 0), 
         @row_userImport$USER_IS_MAIN_LEADER varchar(100), 
         @row_userImport$IMAGE_ID varchar(32), 
         @row_userImport$LOGIN_TIME datetime2(0), 
         @row_userImport$EDIT_TIME varchar(32), 
         @row_userImport$PW_MODIFY_DATE varchar(32), 
         @row_userImport$PW_EXPIRE_FLAG char(1), 
         @row_userImport$PW_PERIOD numeric(38, 0), 
         /*
         *   SSMA warning messages:
         *   O2SS0356: Conversion from NUMBER datatype can cause data loss.
         */

         @row_userImport$CALL_QUANTITY float(53), 
         @row_userImport$CALL_SET varchar(2), 
         @row_userImport$USER_BIRTH_DAY varchar(19), 
         @row_userImport$COMM_APPID varchar(50)

      
      /*
      *   --------------------------------------------------------------------------------------
      *   -------用户的账号可以当成主键看待------------------
      *   --------------------------------------------------------------------------------------
      *   统一'/''\'为'/'防止录入时手误
      */
      UPDATE dbo.TBL_SYS_USER_TEMP
         SET 
            DEPT_ID = replace(t.DEPT_ID, '\', '/')
      FROM dbo.TBL_SYS_USER_TEMP  AS t

      IF @@TRANCOUNT > 0
         COMMIT WORK 

      /*为了和主表的dept_tier字段保持一致,方便查询部门编号*/
      UPDATE dbo.TBL_SYS_USER_TEMP
         SET 
            DEPT_ID = ISNULL(@deptNameParam, '') + ISNULL(replace(t.DEPT_ID, '/', '-'), '')
      FROM dbo.TBL_SYS_USER_TEMP  AS t

      IF @@TRANCOUNT > 0
         COMMIT WORK 

      DECLARE
         @l_c$user_id varchar(max), 
         @l_c$dept_id varchar(max), 
         @l_c$user_accounts varchar(max), 
         @l_c$user_name varchar(max), 
         @l_c$user_sex varchar(max), 
         @l_c$user_is_main_leader varchar(max), 
         @l_c$user_phone varchar(max), 
         @l_c$user_mobile varchar(max), 
         @l_c$user_email varchar(max), 
         /*
         *   SSMA warning messages:
         *   O2SS0356: Conversion from NUMBER datatype can cause data loss.
         */

         @l_c$user_px float(53)

      DECLARE
          c CURSOR LOCAL FORWARD_ONLY FOR 
            SELECT 
               TBL_SYS_USER_TEMP.USER_ID, 
               TBL_SYS_USER_TEMP.DEPT_ID, 
               TBL_SYS_USER_TEMP.USER_ACCOUNTS, 
               TBL_SYS_USER_TEMP.USER_NAME, 
               TBL_SYS_USER_TEMP.USER_SEX, 
               TBL_SYS_USER_TEMP.USER_IS_MAIN_LEADER, 
               TBL_SYS_USER_TEMP.USER_PHONE, 
               TBL_SYS_USER_TEMP.USER_MOBILE, 
               TBL_SYS_USER_TEMP.USER_EMAIL, 
               TBL_SYS_USER_TEMP.USER_PX
            FROM dbo.TBL_SYS_USER_TEMP

      OPEN c

      /*修改导入文件中性别和领导属性两个字段,把汉子替换成数字*/
      WHILE 1 = 1
      
         BEGIN

            FETCH c
                INTO 
                  @l_c$user_id, 
                  @l_c$dept_id, 
                  @l_c$user_accounts, 
                  @l_c$user_name, 
                  @l_c$user_sex, 
                  @l_c$user_is_main_leader, 
                  @l_c$user_phone, 
                  @l_c$user_mobile, 
                  @l_c$user_email, 
                  @l_c$user_px

            IF @@FETCH_STATUS = -1
               BREAK

            UPDATE dbo.TBL_SYS_USER_TEMP
               SET 
                  USER_SEX = 
                     (
                        SELECT 
                           CASE 
                              WHEN t1.USER_SEX = '男' THEN 1
                              WHEN t.USER_SEX = '女' THEN 2
                           END AS expr
                        FROM dbo.TBL_SYS_USER_TEMP  AS t1
                        WHERE t1.USER_ACCOUNTS = @l_c$user_accounts
                     ), 
                  USER_IS_MAIN_LEADER = 
                     (
                        SELECT 
                           CASE 
                              WHEN t2.USER_IS_MAIN_LEADER = '正职领导' THEN 0
                              WHEN t2.USER_IS_MAIN_LEADER = '副职领导' THEN 1
                              WHEN t2.USER_IS_MAIN_LEADER = '否' THEN 2
                           END AS expr
                        FROM dbo.TBL_SYS_USER_TEMP  AS t2
                        WHERE t2.USER_ACCOUNTS = @l_c$user_accounts
                     )
            FROM dbo.TBL_SYS_USER_TEMP  AS t
            WHERE t.USER_ACCOUNTS = @l_c$user_accounts

            IF @@TRANCOUNT > 0
               COMMIT WORK 

         END

      CLOSE c

      DEALLOCATE c

      /*-更新部门ID到临时表*/
      UPDATE dbo.TBL_SYS_USER_TEMP
         SET 
            DEPT_ID = 
               (
                  /*根据输入的部门名称匹配出部门的id*/
                  SELECT TOP 1 t.DEPT_ID
                  FROM dbo.TBL_SYS_DEPARTMENT  AS t
                  WHERE t.DEPT_TIER = t1.DEPT_ID AND t.COMM_RECORD_IDENTY != '3'
               )
      FROM dbo.TBL_SYS_USER_TEMP  AS t1
      WHERE t1.COMM_RECORD_IDENTY IS NULL

      IF @@TRANCOUNT > 0
         COMMIT WORK 

	--删除部门为空的用户
     delete from TBL_SYS_USER_TEMP where DEPT_ID = '' or DEPT_ID is null;
     commit work
	 
      DECLARE
         @l_c$user_id$2 varchar(max), 
         @l_c$dept_id$2 varchar(max), 
         @l_c$user_accounts$2 varchar(max), 
         @l_c$user_name$2 varchar(max), 
         @l_c$user_sex$2 varchar(max), 
         @l_c$user_is_main_leader$2 varchar(max), 
         @l_c$user_phone$2 varchar(max), 
         @l_c$user_mobile$2 varchar(max), 
         @l_c$user_email$2 varchar(max), 
         /*
         *   SSMA warning messages:
         *   O2SS0356: Conversion from NUMBER datatype can cause data loss.
         */

         @l_c$user_px$2 float(53)

      DECLARE
          c CURSOR LOCAL FORWARD_ONLY FOR 
            SELECT 
               TBL_SYS_USER_TEMP.USER_ID, 
               TBL_SYS_USER_TEMP.DEPT_ID, 
               TBL_SYS_USER_TEMP.USER_ACCOUNTS, 
               TBL_SYS_USER_TEMP.USER_NAME, 
               TBL_SYS_USER_TEMP.USER_SEX, 
               TBL_SYS_USER_TEMP.USER_IS_MAIN_LEADER, 
               TBL_SYS_USER_TEMP.USER_PHONE, 
               TBL_SYS_USER_TEMP.USER_MOBILE, 
               TBL_SYS_USER_TEMP.USER_EMAIL, 
               TBL_SYS_USER_TEMP.USER_PX
            FROM dbo.TBL_SYS_USER_TEMP

      OPEN c

      /*------------------删除用户兼职表,用户角色中间表中更新前的数据---------*/
      WHILE 1 = 1
      
         BEGIN

            FETCH c
                INTO 
                  @l_c$user_id$2, 
                  @l_c$dept_id$2, 
                  @l_c$user_accounts$2, 
                  @l_c$user_name$2, 
                  @l_c$user_sex$2, 
                  @l_c$user_is_main_leader$2, 
                  @l_c$user_phone$2, 
                  @l_c$user_mobile$2, 
                  @l_c$user_email$2, 
                  @l_c$user_px$2

            IF @@FETCH_STATUS = -1
               BREAK

            DELETE dbo.TBL_SYS_USER_DEPARTMENT
            FROM dbo.TBL_SYS_USER_DEPARTMENT  AS td
            WHERE td.USER_ID = 
               (
                  SELECT t.USER_ID
                  FROM dbo.TBL_SYS_USER  AS t
                  WHERE t.USER_ACCOUNTS = @l_c$user_accounts$2
               )

            DELETE dbo.TBL_SYS_USER_ROLE
            FROM dbo.TBL_SYS_USER_ROLE  AS tur
            WHERE tur.USER_ID = 
               (
                  SELECT t1.USER_ID
                  FROM dbo.TBL_SYS_USER  AS t1
                  WHERE t1.USER_ACCOUNTS = @l_c$user_accounts$2
               )

            IF @@TRANCOUNT > 0
               COMMIT WORK 

         END

      CLOSE c

      DEALLOCATE c

      IF @@TRANCOUNT > 0
         COMMIT WORK 

	--------------------更新临时表中岗位所属部门信息---------
  DECLARE
		 @l_d$duty_dept_id varchar(max),
         @l_d$user_accounts varchar(max)
   DECLARE
          c CURSOR LOCAL FORWARD_ONLY FOR 
            select 
            tbl_sys_user_temp.DUTY_DEPT_ID,
            tbl_sys_user_temp.USER_ACCOUNTS
             from tbl_sys_user_temp;
      OPEN c     
      WHILE 1 = 1
         BEGIN
            FETCH c
                INTO 
                  @l_d$duty_dept_id,
                  @l_d$user_accounts
            IF @@FETCH_STATUS = -1
               BREAK
			update tbl_sys_user_temp 
			set DUTY_DEPT_ID=(select dept_id from tbl_sys_department where DEPT_TIER=@l_d$duty_dept_id and COMM_RECORD_IDENTY=1)
			 where USER_ACCOUNTS=@l_d$user_accounts;
            
         END
      CLOSE c
      DEALLOCATE c 
  
      DECLARE
         @l_c$user_id$3 varchar(max), 
         @l_c$dept_id$3 varchar(max), 
         @l_c$user_accounts$3 varchar(max), 
         @l_c$user_name$3 varchar(max), 
         @l_c$user_sex$3 varchar(max), 
         @l_c$user_is_main_leader$3 varchar(max), 
         @l_c$user_phone$3 varchar(max), 
         @l_c$user_mobile$3 varchar(max), 
         @l_c$user_email$3 varchar(max), 
         @l_c$user_px$3 float(53),
         @l_c$duty_name$3 varchar(max), 
         @l_c$duty_dept_id$3 varchar(max)

      DECLARE
          c CURSOR LOCAL FORWARD_ONLY FOR 
            SELECT 
               TBL_SYS_USER_TEMP.USER_ID, 
               TBL_SYS_USER_TEMP.DEPT_ID, 
               TBL_SYS_USER_TEMP.USER_ACCOUNTS, 
               TBL_SYS_USER_TEMP.USER_NAME, 
               TBL_SYS_USER_TEMP.USER_SEX, 
               TBL_SYS_USER_TEMP.USER_IS_MAIN_LEADER, 
               TBL_SYS_USER_TEMP.USER_PHONE, 
               TBL_SYS_USER_TEMP.USER_MOBILE, 
               TBL_SYS_USER_TEMP.USER_EMAIL, 
               TBL_SYS_USER_TEMP.USER_PX,
               TBL_SYS_USER_TEMP.DUTY_NAME,
               TBL_SYS_USER_TEMP.DUTY_DEPT_ID
            FROM dbo.TBL_SYS_USER_TEMP

      OPEN c

      /*-------------把更新后结果更新到用户表-----------------------*/
      WHILE 1 = 1
      
         BEGIN

            FETCH c
                INTO 
                  @l_c$user_id$3, 
                  @l_c$dept_id$3, 
                  @l_c$user_accounts$3, 
                  @l_c$user_name$3, 
                  @l_c$user_sex$3, 
                  @l_c$user_is_main_leader$3, 
                  @l_c$user_phone$3, 
                  @l_c$user_mobile$3, 
                  @l_c$user_email$3, 
                  @l_c$user_px$3,
                  @l_c$duty_name$3,
                  @l_c$duty_dept_id$3
            IF @@FETCH_STATUS = -1
               BREAK

            SELECT @usernum = count_big(*)
            FROM dbo.TBL_SYS_USER
            WHERE TBL_SYS_USER.USER_ACCOUNTS = @l_c$user_accounts$3

            /*如果部门id相同的话,更新数据到用户表*/
            IF @usernum = 1
               UPDATE dbo.TBL_SYS_USER
                  SET 
                     /* user_id = l_c.user_id,*/DEPT_ID = @l_c$dept_id$3, 
                     USER_NAME = @l_c$user_name$3, 
                     USER_SEX = @l_c$user_sex$3, 
                     USER_IS_MAIN_LEADER = @l_c$user_is_main_leader$3, 
                     USER_PHONE = @l_c$user_phone$3, 
                     USER_MOBILE = @l_c$user_mobile$3, 
                     USER_EMAIL = @l_c$user_email$3, 
                     USER_PX = @l_c$user_px$3,
                     DICT_ID = (select distinct d.post_duty_id from TBL_PERSONNEL_POSITION_DUTY d where d.post_name=@l_c$duty_name$3 and d.DEPT_ID=@l_c$duty_dept_id$3)
               WHERE TBL_SYS_USER.USER_ACCOUNTS = @l_c$user_accounts$3
            /*如果部门id不相同,就新增数据到用户表*/
            ELSE 
               BEGIN

                  INSERT dbo.TBL_SYS_USER(
                     USER_ID, 
                     DEPT_ID, 
                     USER_ACCOUNTS, 
                     USER_NAME, 
                     USER_SEX, 
                     USER_IS_MAIN_LEADER, 
                     USER_PHONE, 
                     USER_MOBILE, 
                     USER_EMAIL, 
                     USER_PX,
                     DICT_ID)
                     VALUES (
                        @l_c$user_id$3, 
                        @l_c$dept_id$3, 
                        @l_c$user_accounts$3, 
                        @l_c$user_name$3, 
                        @l_c$user_sex$3, 
                        @l_c$user_is_main_leader$3, 
                        @l_c$user_phone$3, 
                        @l_c$user_mobile$3, 
                        @l_c$user_email$3, 
                        @l_c$user_px$3,
					    (select distinct d.post_duty_id from TBL_PERSONNEL_POSITION_DUTY d where d.post_name=@l_c$duty_name$3 and d.DEPT_ID=@l_c$duty_dept_id$3)
					)

                  IF @@TRANCOUNT > 0
                     COMMIT WORK 

               END

         END

      CLOSE c

      DEALLOCATE c

      IF @@TRANCOUNT > 0
         COMMIT WORK 

      DECLARE
         @l_cu$USER_ID varchar(32), 
         @l_cu$DEPT_ID varchar(32), 
         @l_cu$USER_ACCOUNTS varchar(20), 
         @l_cu$USER_CODE varchar(100), 
         @l_cu$USER_NAME varchar(40), 
         @l_cu$USER_NAME_SPELL varchar(600), 
         @l_cu$USER_SEX varchar(32), 
         @l_cu$DICT_ID varchar(32), 
         @l_cu$THEM_ID varchar(32), 
         @l_cu$USER_STANDBY_NAME varchar(40), 
         @l_cu$USER_COMP_IP varchar(128), 
         @l_cu$USER_LEADER_FLAG varchar(1), 
         @l_cu$USER_PASSWORD varchar(128), 
         @l_cu$USER_EFFECT_DATE datetime2(0), 
         @l_cu$USER_CANCEL_DATE datetime2(0), 
         @l_cu$USER_PHONE varchar(40), 
         @l_cu$USER_MOBILE varchar(40), 
         @l_cu$USER_MOBILE_IS_HIDE varchar(1), 
         @l_cu$USER_QQ varchar(32), 
         @l_cu$USER_MSN varchar(255), 
         @l_cu$USER_EMAIL varchar(255), 
         @l_cu$USER_IS_ONLINE varchar(1), 
         /*
         *   SSMA warning messages:
         *   O2SS0356: Conversion from NUMBER datatype can cause data loss.
         */

         @l_cu$SORT_ORDER float(53), 
         @l_cu$USER_TYPE_ID varchar(32), 
         @l_cu$USER_REMARK varchar(600), 
         @l_cu$COMM_CREATOR varchar(32), 
         @l_cu$COMM_CREATE_TIME char(19), 
         @l_cu$COMM_RECORD_IDENTY numeric(38, 0), 
         @l_cu$COMM_EDITION_ID varchar(32), 
         @l_cu$COMM_EDITION_NO numeric(38, 0), 
         @l_cu$COMM_BUINESS_ORDER numeric(38, 0), 
         @l_cu$COMM_ORG_LEVEL varchar(60), 
         @l_cu$COMM_ORG_IDENTY varchar(60), 
         @l_cu$COMM_CHANGE_NOTICE varchar(60), 
         @l_cu$BLANK0 varchar(100), 
         @l_cu$BLANK1 varchar(100), 
         @l_cu$BLANK2 varchar(100), 
         @l_cu$PAY_PASSWORD varchar(100), 
         @l_cu$USER_PX numeric(38, 0), 
         @l_cu$USER_IS_MAIN_LEADER varchar(2), 
         @l_cu$IMAGE_ID varchar(32), 
         @l_cu$LOGIN_TIME datetime2(0), 
         @l_cu$EDIT_TIME varchar(32), 
         @l_cu$PW_MODIFY_DATE varchar(32), 
         @l_cu$PW_EXPIRE_FLAG char(1), 
         @l_cu$PW_PERIOD numeric(38, 0), 
         /*
         *   SSMA warning messages:
         *   O2SS0356: Conversion from NUMBER datatype can cause data loss.
         */

         @l_cu$CALL_QUANTITY float(53), 
         @l_cu$CALL_SET varchar(2), 
         @l_cu$USER_BIRTH_DAY varchar(19), 
         @l_cu$COMM_APPID varchar(50)

      DECLARE
          cu CURSOR LOCAL FORWARD_ONLY FOR 
            SELECT 
               TBL_SYS_USER.USER_ID, 
               TBL_SYS_USER.DEPT_ID, 
               TBL_SYS_USER.USER_ACCOUNTS, 
               TBL_SYS_USER.USER_CODE, 
               TBL_SYS_USER.USER_NAME, 
               TBL_SYS_USER.USER_NAME_SPELL, 
               TBL_SYS_USER.USER_SEX, 
               TBL_SYS_USER.DICT_ID, 
               TBL_SYS_USER.THEM_ID, 
               TBL_SYS_USER.USER_STANDBY_NAME, 
               TBL_SYS_USER.USER_COMP_IP, 
               TBL_SYS_USER.USER_LEADER_FLAG, 
               TBL_SYS_USER.USER_PASSWORD, 
               TBL_SYS_USER.USER_EFFECT_DATE, 
               TBL_SYS_USER.USER_CANCEL_DATE, 
               TBL_SYS_USER.USER_PHONE, 
               TBL_SYS_USER.USER_MOBILE, 
               TBL_SYS_USER.USER_MOBILE_IS_HIDE, 
               TBL_SYS_USER.USER_QQ, 
               TBL_SYS_USER.USER_MSN, 
               TBL_SYS_USER.USER_EMAIL, 
               TBL_SYS_USER.USER_IS_ONLINE, 
               TBL_SYS_USER.SORT_ORDER, 
               TBL_SYS_USER.USER_TYPE_ID, 
               TBL_SYS_USER.USER_REMARK, 
               TBL_SYS_USER.COMM_CREATOR, 
               TBL_SYS_USER.COMM_CREATE_TIME, 
               TBL_SYS_USER.COMM_RECORD_IDENTY, 
               TBL_SYS_USER.COMM_EDITION_ID, 
               TBL_SYS_USER.COMM_EDITION_NO, 
               TBL_SYS_USER.COMM_BUINESS_ORDER, 
               TBL_SYS_USER.COMM_ORG_LEVEL, 
               TBL_SYS_USER.COMM_ORG_IDENTY, 
               TBL_SYS_USER.COMM_CHANGE_NOTICE, 
               TBL_SYS_USER.BLANK0, 
               TBL_SYS_USER.BLANK1, 
               TBL_SYS_USER.BLANK2, 
               TBL_SYS_USER.PAY_PASSWORD, 
               TBL_SYS_USER.USER_PX, 
               TBL_SYS_USER.USER_IS_MAIN_LEADER, 
               TBL_SYS_USER.IMAGE_ID, 
               TBL_SYS_USER.LOGIN_TIME, 
               TBL_SYS_USER.EDIT_TIME, 
               TBL_SYS_USER.PW_MODIFY_DATE, 
               TBL_SYS_USER.PW_EXPIRE_FLAG, 
               TBL_SYS_USER.PW_PERIOD, 
               TBL_SYS_USER.CALL_QUANTITY, 
               TBL_SYS_USER.CALL_SET, 
               TBL_SYS_USER.USER_BIRTH_DAY, 
               TBL_SYS_USER.COMM_APPID
            FROM dbo.TBL_SYS_USER

      OPEN cu

      /*------------如果用户已经存在需要更新临时表中user_id-------------*/
      WHILE 1 = 1
      
         BEGIN

            FETCH cu
                INTO 
                  @l_cu$USER_ID, 
                  @l_cu$DEPT_ID, 
                  @l_cu$USER_ACCOUNTS, 
                  @l_cu$USER_CODE, 
                  @l_cu$USER_NAME, 
                  @l_cu$USER_NAME_SPELL, 
                  @l_cu$USER_SEX, 
                  @l_cu$DICT_ID, 
                  @l_cu$THEM_ID, 
                  @l_cu$USER_STANDBY_NAME, 
                  @l_cu$USER_COMP_IP, 
                  @l_cu$USER_LEADER_FLAG, 
                  @l_cu$USER_PASSWORD, 
                  @l_cu$USER_EFFECT_DATE, 
                  @l_cu$USER_CANCEL_DATE, 
                  @l_cu$USER_PHONE, 
                  @l_cu$USER_MOBILE, 
                  @l_cu$USER_MOBILE_IS_HIDE, 
                  @l_cu$USER_QQ, 
                  @l_cu$USER_MSN, 
                  @l_cu$USER_EMAIL, 
                  @l_cu$USER_IS_ONLINE, 
                  @l_cu$SORT_ORDER, 
                  @l_cu$USER_TYPE_ID, 
                  @l_cu$USER_REMARK, 
                  @l_cu$COMM_CREATOR, 
                  @l_cu$COMM_CREATE_TIME, 
                  @l_cu$COMM_RECORD_IDENTY, 
                  @l_cu$COMM_EDITION_ID, 
                  @l_cu$COMM_EDITION_NO, 
                  @l_cu$COMM_BUINESS_ORDER, 
                  @l_cu$COMM_ORG_LEVEL, 
                  @l_cu$COMM_ORG_IDENTY, 
                  @l_cu$COMM_CHANGE_NOTICE, 
                  @l_cu$BLANK0, 
                  @l_cu$BLANK1, 
                  @l_cu$BLANK2, 
                  @l_cu$PAY_PASSWORD, 
                  @l_cu$USER_PX, 
                  @l_cu$USER_IS_MAIN_LEADER, 
                  @l_cu$IMAGE_ID, 
                  @l_cu$LOGIN_TIME, 
                  @l_cu$EDIT_TIME, 
                  @l_cu$PW_MODIFY_DATE, 
                  @l_cu$PW_EXPIRE_FLAG, 
                  @l_cu$PW_PERIOD, 
                  @l_cu$CALL_QUANTITY, 
                  @l_cu$CALL_SET, 
                  @l_cu$USER_BIRTH_DAY, 
                  @l_cu$COMM_APPID

            IF @@FETCH_STATUS = -1
               BREAK

            SELECT @usernum = count_big(*)
            FROM dbo.TBL_SYS_USER_TEMP
            WHERE TBL_SYS_USER_TEMP.USER_ACCOUNTS = @l_cu$USER_ACCOUNTS

            /*如果部门id相同的话,更新数据到用户表*/
            IF @usernum = 1
               UPDATE dbo.TBL_SYS_USER_TEMP
                  SET 
                     USER_ID = @l_cu$USER_ID
               WHERE TBL_SYS_USER_TEMP.USER_ACCOUNTS = @l_cu$USER_ACCOUNTS
            ELSE 
               BEGIN
                  IF @@TRANCOUNT > 0
                     COMMIT WORK 
               END

         END

      CLOSE cu

      DEALLOCATE cu

      DECLARE
         @row_userImport$USER_ID$2 varchar(32), 
         @row_userImport$DEPT_ID$2 varchar(2000), 
         @row_userImport$USER_ACCOUNTS$2 varchar(20), 
         @row_userImport$USER_CODE$2 varchar(100), 
         @row_userImport$USER_NAME$2 varchar(40), 
         @row_userImport$USER_NAME_SPELL$2 varchar(600), 
         @row_userImport$USER_SEX$2 varchar(32), 
         @row_userImport$DICT_ID$2 varchar(32), 
         @row_userImport$THEM_ID$2 varchar(32), 
         @row_userImport$USER_STANDBY_NAME$2 varchar(40), 
         @row_userImport$USER_COMP_IP$2 varchar(128), 
         @row_userImport$USER_LEADER_FLAG$2 varchar(1), 
         @row_userImport$USER_PASSWORD$2 varchar(128), 
         @row_userImport$USER_EFFECT_DATE$2 datetime2(0), 
         @row_userImport$USER_CANCEL_DATE$2 datetime2(0), 
         @row_userImport$USER_PHONE$2 varchar(40), 
         @row_userImport$USER_MOBILE$2 varchar(40), 
         @row_userImport$USER_MOBILE_IS_HIDE$2 varchar(1), 
         @row_userImport$USER_QQ$2 varchar(32), 
         @row_userImport$USER_MSN$2 varchar(255), 
         @row_userImport$USER_EMAIL$2 varchar(255), 
         @row_userImport$USER_IS_ONLINE$2 varchar(1), 
         /*
         *   SSMA warning messages:
         *   O2SS0356: Conversion from NUMBER datatype can cause data loss.
         */

         @row_userImport$SORT_ORDER$2 float(53), 
         @row_userImport$USER_TYPE_ID$2 varchar(32), 
         @row_userImport$USER_REMARK$2 varchar(600), 
         @row_userImport$COMM_CREATOR$2 varchar(32), 
         @row_userImport$COMM_CREATE_TIME$2 char(19), 
         @row_userImport$COMM_RECORD_IDENTY$2 numeric(38, 0), 
         @row_userImport$COMM_EDITION_ID$2 varchar(32), 
         @row_userImport$COMM_EDITION_NO$2 numeric(38, 0), 
         @row_userImport$COMM_BUINESS_ORDER$2 numeric(38, 0), 
         @row_userImport$COMM_ORG_LEVEL$2 varchar(60), 
         @row_userImport$COMM_ORG_IDENTY$2 varchar(60), 
         @row_userImport$COMM_CHANGE_NOTICE$2 varchar(60), 
         @row_userImport$BLANK0$2 varchar(100), 
         @row_userImport$BLANK1$2 varchar(100), 
         @row_userImport$BLANK2$2 varchar(100), 
         @row_userImport$PAY_PASSWORD$2 varchar(100), 
         @row_userImport$USER_PX$2 numeric(38, 0), 
         @row_userImport$USER_IS_MAIN_LEADER$2 varchar(100), 
         @row_userImport$IMAGE_ID$2 varchar(32), 
         @row_userImport$LOGIN_TIME$2 datetime2(0), 
         @row_userImport$EDIT_TIME$2 varchar(32), 
         @row_userImport$PW_MODIFY_DATE$2 varchar(32), 
         @row_userImport$PW_EXPIRE_FLAG$2 char(1), 
         @row_userImport$PW_PERIOD$2 numeric(38, 0), 
         /*
         *   SSMA warning messages:
         *   O2SS0356: Conversion from NUMBER datatype can cause data loss.
         */

         @row_userImport$CALL_QUANTITY$2 float(53), 
         @row_userImport$CALL_SET$2 varchar(2), 
         @row_userImport$USER_BIRTH_DAY$2 varchar(19), 
         @row_userImport$DUTY_NAME$2 varchar(64), 
         @row_userImport$DUTY_DEPT_ID$2 varchar(max), 
         @row_userImport$COMM_APPID$2 varchar(50)

      DECLARE
          user_import CURSOR LOCAL FORWARD_ONLY FOR 
            SELECT 
               t.USER_ID, 
               t.DEPT_ID, 
               t.USER_ACCOUNTS, 
               t.USER_CODE, 
               t.USER_NAME, 
               t.USER_NAME_SPELL, 
               t.USER_SEX, 
               t.DICT_ID, 
               t.THEM_ID, 
               t.USER_STANDBY_NAME, 
               t.USER_COMP_IP, 
               t.USER_LEADER_FLAG, 
               t.USER_PASSWORD, 
               t.USER_EFFECT_DATE, 
               t.USER_CANCEL_DATE, 
               t.USER_PHONE, 
               t.USER_MOBILE, 
               t.USER_MOBILE_IS_HIDE, 
               t.USER_QQ, 
               t.USER_MSN, 
               t.USER_EMAIL, 
               t.USER_IS_ONLINE, 
               t.SORT_ORDER, 
               t.USER_TYPE_ID, 
               t.USER_REMARK, 
               t.COMM_CREATOR, 
               t.COMM_CREATE_TIME, 
               t.COMM_RECORD_IDENTY, 
               t.COMM_EDITION_ID, 
               t.COMM_EDITION_NO, 
               t.COMM_BUINESS_ORDER, 
               t.COMM_ORG_LEVEL, 
               t.COMM_ORG_IDENTY, 
               t.COMM_CHANGE_NOTICE, 
               t.BLANK0, 
               t.BLANK1, 
               t.BLANK2, 
               t.PAY_PASSWORD, 
               t.USER_PX, 
               t.USER_IS_MAIN_LEADER, 
               t.IMAGE_ID, 
               t.LOGIN_TIME, 
               t.EDIT_TIME, 
               t.PW_MODIFY_DATE, 
               t.PW_EXPIRE_FLAG, 
               t.PW_PERIOD, 
               t.CALL_QUANTITY, 
               t.CALL_SET, 
               t.USER_BIRTH_DAY, 
               t.DUTY_NAME,
               t.DUTY_DEPT_ID,
               t.COMM_APPID
            FROM dbo.TBL_SYS_USER_TEMP  AS t
            WHERE t.COMM_RECORD_IDENTY IS NULL

      OPEN user_import

      /*---------------------------------------------------------------*/
      WHILE 1 = 1
      
         BEGIN

            FETCH user_import
                INTO 
                  @row_userImport$USER_ID$2, 
                  @row_userImport$DEPT_ID$2, 
                  @row_userImport$USER_ACCOUNTS$2, 
                  @row_userImport$USER_CODE$2, 
                  @row_userImport$USER_NAME$2, 
                  @row_userImport$USER_NAME_SPELL$2, 
                  @row_userImport$USER_SEX$2, 
                  @row_userImport$DICT_ID$2, 
                  @row_userImport$THEM_ID$2, 
                  @row_userImport$USER_STANDBY_NAME$2, 
                  @row_userImport$USER_COMP_IP$2, 
                  @row_userImport$USER_LEADER_FLAG$2, 
                  @row_userImport$USER_PASSWORD$2, 
                  @row_userImport$USER_EFFECT_DATE$2, 
                  @row_userImport$USER_CANCEL_DATE$2, 
                  @row_userImport$USER_PHONE$2, 
                  @row_userImport$USER_MOBILE$2, 
                  @row_userImport$USER_MOBILE_IS_HIDE$2, 
                  @row_userImport$USER_QQ$2, 
                  @row_userImport$USER_MSN$2, 
                  @row_userImport$USER_EMAIL$2, 
                  @row_userImport$USER_IS_ONLINE$2, 
                  @row_userImport$SORT_ORDER$2, 
                  @row_userImport$USER_TYPE_ID$2, 
                  @row_userImport$USER_REMARK$2, 
                  @row_userImport$COMM_CREATOR$2, 
                  @row_userImport$COMM_CREATE_TIME$2, 
                  @row_userImport$COMM_RECORD_IDENTY$2, 
                  @row_userImport$COMM_EDITION_ID$2, 
                  @row_userImport$COMM_EDITION_NO$2, 
                  @row_userImport$COMM_BUINESS_ORDER$2, 
                  @row_userImport$COMM_ORG_LEVEL$2, 
                  @row_userImport$COMM_ORG_IDENTY$2, 
                  @row_userImport$COMM_CHANGE_NOTICE$2, 
                  @row_userImport$BLANK0$2, 
                  @row_userImport$BLANK1$2, 
                  @row_userImport$BLANK2$2, 
                  @row_userImport$PAY_PASSWORD$2, 
                  @row_userImport$USER_PX$2, 
                  @row_userImport$USER_IS_MAIN_LEADER$2, 
                  @row_userImport$IMAGE_ID$2, 
                  @row_userImport$LOGIN_TIME$2, 
                  @row_userImport$EDIT_TIME$2, 
                  @row_userImport$PW_MODIFY_DATE$2, 
                  @row_userImport$PW_EXPIRE_FLAG$2, 
                  @row_userImport$PW_PERIOD$2, 
                  @row_userImport$CALL_QUANTITY$2, 
                  @row_userImport$CALL_SET$2, 
                  @row_userImport$USER_BIRTH_DAY$2, 
                  @row_userImport$DUTY_NAME$2, 
                  @row_userImport$DUTY_DEPT_ID$2, 
                  @row_userImport$COMM_APPID$2

            IF @@FETCH_STATUS = -1
               BREAK

            /*更新user表*/
            UPDATE dbo.TBL_SYS_USER
               SET 
                  USER_PASSWORD = '356A192B7913B04C54574D18C28D46E6395428AB', 
                  USER_IS_ONLINE = '0', 
                  COMM_RECORD_IDENTY = 1, 
                  USER_IS_MAIN_LEADER = isnull(@row_userImport$USER_IS_MAIN_LEADER$2, 2), 
                  COMM_ORG_IDENTY = 
                     (
                        SELECT d.COMM_ORG_IDENTY
                        FROM dbo.TBL_SYS_DEPARTMENT  AS d
                        WHERE d.DEPT_ID = t.DEPT_ID
                     ), 
                  COMM_ORG_LEVEL = 
                     (
                        SELECT dd.COMM_ORG_LEVEL
                        FROM dbo.TBL_SYS_DEPARTMENT  AS dd
                        WHERE dd.DEPT_ID = t.DEPT_ID
                     ), 
                  THEM_ID = '402881a92408b498012408b877fa0003'
            FROM dbo.TBL_SYS_USER  AS t
            WHERE t.USER_ACCOUNTS = @row_userImport$USER_ACCOUNTS$2


            
            /*
            *   ---------------------------------------------------------------------
            *   给用户家角色
            */
            
            if(@row_userImport$USER_IS_MAIN_LEADER$2=0)
            begin
            INSERT dbo.TBL_SYS_USER_ROLE(UROL_ID, USER_ID, ROLE_ID)
               VALUES (LOWER(REPLACE(LTRIM(NEWID()),'-','')), @row_userImport$USER_ID$2, 
                  (
                     select t.ROLE_ID from TBL_SYS_ROLE t 
                     where t.ROLE_NAME=( '正职领导') 
                     and t.COMM_ORG_IDENTY=(
						 select distinct d.COMM_ORG_IDENTY from TBL_SYS_DEPARTMENT d 
						 where d.DEPT_ID=@row_userImport$DEPT_ID$2
						 and d.COMM_RECORD_IDENTY=1
                     ) 
                     and t.COMM_RECORD_IDENTY=1
					 and t.dept_id = (select dept_id from tbl_sys_department where COMM_ORG_IDENTY in (select distinct d.COMM_ORG_IDENTY from TBL_SYS_DEPARTMENT d
                       where d.DEPT_ID=@row_userImport$DEPT_ID$2
                       and d.COMM_RECORD_IDENTY=1) and dept_flag=1)
                  ));
                  INSERT dbo.TBL_SYS_USER_ROLE(UROL_ID, USER_ID, ROLE_ID)
						  VALUES (LOWER(REPLACE(LTRIM(NEWID()),'-','')), @row_userImport$USER_ID$2, 
						  (
							 select t.ROLE_ID from TBL_SYS_ROLE t 
							 where t.ROLE_NAME=( '系统用户') 
							 and t.COMM_ORG_IDENTY=(
								 select distinct d.COMM_ORG_IDENTY from TBL_SYS_DEPARTMENT d 
								 where d.DEPT_ID=@row_userImport$DEPT_ID$2
								 and d.COMM_RECORD_IDENTY=1
							 ) 
							 and t.COMM_RECORD_IDENTY=1
							 and t.dept_id = (select dept_id from tbl_sys_department where COMM_ORG_IDENTY in (select distinct d.COMM_ORG_IDENTY from TBL_SYS_DEPARTMENT d where d.DEPT_ID=@row_userImport$DEPT_ID$2 and d.COMM_RECORD_IDENTY=1) and dept_flag=1)
						   )); 
             end
             else if (@row_userImport$USER_IS_MAIN_LEADER$2=1)
				 begin 
					 INSERT dbo.TBL_SYS_USER_ROLE(UROL_ID, USER_ID, ROLE_ID)
					   VALUES (LOWER(REPLACE(LTRIM(NEWID()),'-','')), @row_userImport$USER_ID$2, 
						  (
							 select t.ROLE_ID from TBL_SYS_ROLE t 
							 where t.ROLE_NAME=( '副职领导') 
							 and t.COMM_ORG_IDENTY=(
								 select distinct d.COMM_ORG_IDENTY from TBL_SYS_DEPARTMENT d 
								 where d.DEPT_ID=@row_userImport$DEPT_ID$2
								 and d.COMM_RECORD_IDENTY=1
							 ) 
							 and t.COMM_RECORD_IDENTY=1
							 and t.dept_id = (select dept_id from tbl_sys_department where COMM_ORG_IDENTY in (select distinct d.COMM_ORG_IDENTY from TBL_SYS_DEPARTMENT d where d.DEPT_ID=@row_userImport$DEPT_ID$2 and d.COMM_RECORD_IDENTY=1) and dept_flag=1)
						  ));
						  INSERT dbo.TBL_SYS_USER_ROLE(UROL_ID, USER_ID, ROLE_ID)
						  VALUES (LOWER(REPLACE(LTRIM(NEWID()),'-','')), @row_userImport$USER_ID$2, 
						  (
							 select t.ROLE_ID from TBL_SYS_ROLE t 
							 where t.ROLE_NAME=( '系统用户') 
							 and t.COMM_ORG_IDENTY=(
								 select distinct d.COMM_ORG_IDENTY from TBL_SYS_DEPARTMENT d 
								 where d.DEPT_ID=@row_userImport$DEPT_ID$2
								 and d.COMM_RECORD_IDENTY=1
							 ) 
							 and t.COMM_RECORD_IDENTY=1
							 and t.dept_id = (select dept_id from tbl_sys_department where COMM_ORG_IDENTY in (select distinct d.COMM_ORG_IDENTY from TBL_SYS_DEPARTMENT d where d.DEPT_ID=@row_userImport$DEPT_ID$2 and d.COMM_RECORD_IDENTY=1) and dept_flag=1)
						   ));
				 end
             else
             begin 
               INSERT dbo.TBL_SYS_USER_ROLE(UROL_ID, USER_ID, ROLE_ID)
               VALUES (LOWER(REPLACE(LTRIM(NEWID()),'-','')), @row_userImport$USER_ID$2, 
                  (
                     select t.ROLE_ID from TBL_SYS_ROLE t 
                     where t.ROLE_NAME=( '系统用户') 
                     and t.COMM_ORG_IDENTY=(
						 select distinct d.COMM_ORG_IDENTY from TBL_SYS_DEPARTMENT d 
						 where d.DEPT_ID=@row_userImport$DEPT_ID$2
						 and d.COMM_RECORD_IDENTY=1
                     ) 
                     and t.COMM_RECORD_IDENTY=1
					 and t.dept_id = (select dept_id from tbl_sys_department where COMM_ORG_IDENTY in (select distinct d.COMM_ORG_IDENTY from TBL_SYS_DEPARTMENT d where d.DEPT_ID=@row_userImport$DEPT_ID$2 and d.COMM_RECORD_IDENTY=1) and dept_flag=1)
                   ))
             end
            
            /*
            *   -----------------------------------------------------------------
            *   插入兼职表
            */
            INSERT dbo.TBL_SYS_USER_DEPARTMENT(
               USER_DEPT_ID, 
               USER_ID, 
               POST_DUTY_ID, 
               DEPT_ID, 
               USER_SHOW_NAME, 
               USER_SHOW_ID, 
               USER_IS_ONLINE, 
               DEPARTMENT_ID, 
               IS_PARTTIME, 
               LEADER_FLAG, 
               COMM_RECORD_IDENTY, 
               SORT_NUM)
               VALUES (
                  LOWER(REPLACE(LTRIM(NEWID()),'-','')), 
                  @row_userImport$USER_ID$2, 
                  (select distinct d.post_duty_id from TBL_PERSONNEL_POSITION_DUTY d where d.post_name=@row_userImport$DUTY_NAME$2 and d.DEPT_ID=@row_userImport$DUTY_DEPT_ID$2), 
                  NULL, 
                  @row_userImport$USER_NAME$2, 
                  @row_userImport$USER_ID$2, 
                  0, 
                  @row_userImport$DEPT_ID$2, 
                  0, 
                  isnull(@row_userImport$USER_IS_MAIN_LEADER$2, 2), 
                  1, 
                  9999)
			/*
            *   -----------------------------------------------------------------
            *   加入员工档案
            */
            INSERT dbo.TBL_PERSONNEL_USER(
               PERSONNEL_ID, 
               USER_ACCOUNTS, 
               USER_CODE, 
               USER_NAME, 
               USER_NAME_SPELL, 
               USER_SEX, 
               DEPT_ID, 
               USER_LEADER_FLAG, 
               USER_PHONE,
               USER_MOBILE,
               USER_EMAIL,
               SORT_ORDER,
               USER_STATUS,
				USER_ID,
               COMM_RECORD_IDENTY, 
               COMM_ORG_LEVEL, 
               COMM_ORG_IDENTY)
               VALUES (
                  LOWER(REPLACE(LTRIM(NEWID()),'-','')), 
                  @row_userImport$USER_ACCOUNTS$2,
                  @row_userImport$USER_ACCOUNTS$2,
                  @row_userImport$USER_NAME$2, 
                  @row_userImport$USER_NAME_SPELL$2, 
                  @row_userImport$USER_SEX$2, 
                  @row_userImport$DEPT_ID$2, 
                  @row_userImport$USER_LEADER_FLAG$2, 
                  @row_userImport$USER_PHONE$2, 
                  @row_userImport$USER_MOBILE$2, 
                  @row_userImport$USER_EMAIL$2, 
                  @row_userImport$SORT_ORDER$2, 
                  0,
                  @row_userImport$USER_ID$2,
                  1,
                  (SELECT dd.COMM_ORG_LEVEL
                        FROM dbo.TBL_SYS_DEPARTMENT  AS dd
                        WHERE dd.DEPT_ID = @row_userImport$DEPT_ID$2),
                  (SELECT d.COMM_ORG_IDENTY
                        FROM dbo.TBL_SYS_DEPARTMENT  AS d
                        WHERE d.DEPT_ID = @row_userImport$DEPT_ID$2)
                  );
				  
				  insert into tbl_personnel_field_detail
					(PERSONNELDETAIL_ID,
					 FILED_ID,
					 TYPE_ID,
					 USER_ID,
					 FEILD_VALUE,
					 FEILD_BATCH,
					 COMM_CREATOR,
					 COMM_CREATE_TIME2,
					 COMM_RECORD_IDENTY,
					 COMM_EDITION_ID,
					 COMM_EDITION_NO,
					 COMM_BUINESS_ORDER,
					 COMM_ORG_LEVEL,
					 COMM_ORG_IDENTY,
					 COMM_CHANGE_NOTICE,
					 BLANK0,
					 BLANK1,
					 BLANK2)
				  values
					(
					 LOWER(REPLACE(LTRIM(NEWID()),'-','')),
					 '402898263146c84c013146e85a8f0022',
					 '402898263146c84c013146da8d010001',
					 @row_userImport$USER_ID$2,
					 @row_userImport$USER_SEX$2,
					 null,
					 null,
					 null,
					 1,
					 null,
					 null,
					 @row_userImport$SORT_ORDER$2,
					 (SELECT dd.COMM_ORG_LEVEL
						FROM TBL_SYS_DEPARTMENT  dd
						WHERE dd.DEPT_ID = @row_userImport$DEPT_ID$2),
					(SELECT d.COMM_ORG_IDENTY
						  FROM TBL_SYS_DEPARTMENT   d
						  WHERE d.DEPT_ID = @row_userImport$DEPT_ID$2),
					 null,
					 null,
					 null,
					 null);
         END

      CLOSE user_import

      DEALLOCATE user_import

      IF @@TRANCOUNT > 0
         COMMIT WORK 

		 
		 --解决员工档案中男女性别显示问题
			UPDATE dbo.tbl_personnel_field_detail
   SET feild_value = (case
                       when convert(int, t1.feild_value) = 1 then
                        '男'
                       when convert(int, t1.feild_value) = 2 then
                        '女'
                     end) FROM dbo.tbl_personnel_field_detail t1 JOIN dbo.tbl_personnel_field_detail ON dbo.tbl_personnel_field_detail.personneldetail_id = t1.personneldetail_id and t1.feild_value != '男' and t1.feild_value != '女' and t1.feild_value is not null and t1.feild_value != '';
				 
				 IF @@TRANCOUNT > 0
				 COMMIT WORK 
      
      /*
      *   --------------------------------------------------------------------
      *   删除掉临时表中数据
      */
      DELETE dbo.TBL_SYS_USER_TEMP

      IF @@TRANCOUNT > 0
         COMMIT WORK 
      /*------------------------------------------------------------------------*/

   END

go

