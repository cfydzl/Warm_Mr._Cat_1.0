
CREATE PROCEDURE [dbo].[IMPORT_DUTY]  
   @deptIdParam varchar(max)
AS 
   BEGIN

  --部门为空，设置默认部门
	update TBL_DUTY_TEMP set dept_id = (select dept_tier from tbl_sys_department where dept_id=@deptIdParam ) where dept_id is null;
	commit;
  --修改POST_NAME
    update TBL_DUTY_TEMP set dept_id=replace(dept_id,'/','-');
    commit;
 --删除部门不存在的数据
   delete from TBL_DUTY_TEMP where dept_id not in (select dept_tier from tbl_sys_department);
 commit;
 
 --更新dept_id
  DECLARE
         @l_c$dept_id varchar(max), 
         @l_c$post_duty_id varchar(max)
   DECLARE
          c CURSOR LOCAL FORWARD_ONLY FOR 
            select 
            TBL_DUTY_TEMP.dept_id,
            TBL_DUTY_TEMP.post_duty_id
             from TBL_DUTY_TEMP;
      OPEN c
      
      WHILE 1 = 1
      
         BEGIN

            FETCH c
                INTO 
                  @l_c$dept_id, 
                  @l_c$post_duty_id
            IF @@FETCH_STATUS = -1
               BREAK

            update TBL_DUTY_TEMP 
			set dept_id=(select dept_id from tbl_sys_department where DEPT_TIER=@l_c$dept_id and COMM_RECORD_IDENTY=1),
			COMM_ORG_LEVEL=(select COMM_ORG_LEVEL from tbl_sys_department where DEPT_TIER=@l_c$dept_id and COMM_RECORD_IDENTY=1),
			COMM_ORG_IDENTY=(select COMM_ORG_IDENTY from tbl_sys_department where DEPT_TIER=@l_c$dept_id and COMM_RECORD_IDENTY=1)
			 where post_duty_id=@l_c$post_duty_id;

            IF @@TRANCOUNT > 0
               COMMIT WORK 

         END

      CLOSE c

      DEALLOCATE c
      
  --插入岗位数据
  DECLARE
		 @l_d$post_duty_id varchar(max),
         @l_d$post_name varchar(max), 
         @l_d$dept_id varchar(max), 
         @l_d$comm_org_level varchar(max), 
         @l_d$comm_org_identy varchar(max),
         @usernum int
   DECLARE
          c CURSOR LOCAL FORWARD_ONLY FOR 
            select 
            TBL_DUTY_TEMP.post_duty_id,
            TBL_DUTY_TEMP.post_name,
            TBL_DUTY_TEMP.dept_id,
            TBL_DUTY_TEMP.comm_org_level,
            TBL_DUTY_TEMP.comm_org_identy
             from TBL_DUTY_TEMP;
      OPEN c
      
      WHILE 1 = 1
      
         BEGIN

            FETCH c
                INTO 
                  @l_c$post_duty_id,
                  @l_d$post_name,
                  @l_c$dept_id, 
                  @l_d$comm_org_level,
                  @l_d$comm_org_identy
            IF @@FETCH_STATUS = -1
               BREAK

            SELECT @usernum = count_big(*)
            FROM TBL_PERSONNEL_POSITION_DUTY d
			WHERE POST_NAME = @l_d$post_name
			AND DEPT_ID = @l_d$dept_id;

            /*如果部门id相同的话,更新数据到用户表*/
            IF @usernum = 1
               update TBL_PERSONNEL_POSITION_DUTY
				 set comm_org_level=@l_d$comm_org_level,
				 comm_org_identy=@l_d$comm_org_identy
				WHERE post_name = @l_d$post_name AND dept_id = @l_c$dept_id;
            /*如果部门id不相同,就新增数据到用户表*/
            ELSE 
               BEGIN

                  insert into TBL_PERSONNEL_POSITION_DUTY(POST_DUTY_ID, POST_NAME, DEPT_ID, COMM_ORG_LEVEL,COMM_ORG_IDENTY,COMM_RECORD_IDENTY)
                  values(@l_c$post_duty_id,@l_d$post_name,@l_c$dept_id,@l_d$comm_org_level,@l_d$comm_org_identy,1);

                  IF @@TRANCOUNT > 0
                     COMMIT WORK 

               END

         END

      CLOSE c

      DEALLOCATE c
  

--删除掉临时表中数据
  delete from TBL_DUTY_TEMP;
  commit;

   END
go

