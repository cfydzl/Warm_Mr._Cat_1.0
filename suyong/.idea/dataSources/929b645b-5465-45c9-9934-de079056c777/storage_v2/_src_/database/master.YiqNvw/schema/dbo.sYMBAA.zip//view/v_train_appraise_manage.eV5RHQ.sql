CREATE view v_train_appraise_manage as(
select
		row_Number() over (Order by a.train_active_id) as v_id,
		   a.train_active_id as v_train_active_id,
		   a.comm_org_identy as v_comm_org_identy,
		   a.comm_record_identy as v_comm_record_identy,
		   a.train_active_no as v_train_active_no,
		   a.train_active_name as v_train_active_name,
		   a.train_address as v_train_address,
		   a.start_time as v_start_time,
		   a.end_time as v_end_time,
		   b.train_course_id as v_train_course_id,
		   b.teacher_id as v_teacher_id,
		   CASE  WHEN b.teacher_id IS NULL THEN b.teacher_name else u.USER_NAME END as v_teacher_name,
		   b.train_course_no as v_train_course_no,
		   b.train_course_name as v_train_course_name,
		   b.course_eval_state as v_course_eval_state
	  from tbl_train_active a
	  left join TBL_TRAIN_COURSE b on a.train_active_id= b.train_active_id
	  left join TBL_SYS_USER u on b.teacher_id=u.USER_ID 
	  where a.train_type='2' and a.comm_record_identy='1' and a.blank1='0'
 );
go

