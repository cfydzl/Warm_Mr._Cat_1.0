create view v_jihuo_record
as
select Id_num  账号,  Jihuo_time 激活时间
from jihuo_record
go

