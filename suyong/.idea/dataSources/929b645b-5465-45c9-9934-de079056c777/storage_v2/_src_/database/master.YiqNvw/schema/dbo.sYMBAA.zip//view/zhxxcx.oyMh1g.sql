create view zhxxcx as
select card_account_user 账号,card_account_name 名字,card_account_id 卡号,card_account_money 余额,card_account_statu 状态 from card_account
go

