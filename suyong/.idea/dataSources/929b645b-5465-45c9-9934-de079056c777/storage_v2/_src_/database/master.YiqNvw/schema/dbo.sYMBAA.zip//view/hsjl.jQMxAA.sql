create view hsjl as
select return_book_user 账号,return_book_id 书本ID,return_book_time 时间 from return_book
go

