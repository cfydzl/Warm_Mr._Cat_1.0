create view v_buban_record
as
select  Id_num 账号,  Bu_time 补办时间, Id_pop 经办人
from buban_record
go

