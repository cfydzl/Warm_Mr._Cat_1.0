create view book_sum as
select book_id  ID号,book_name 书名,book_type 类型,book_status 状态
from book_id
go

