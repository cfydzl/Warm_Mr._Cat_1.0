create view jgjl as
select relose_user 账号,relose_id 卡号,relose_time 时间,relose_opt 经办人 from relose where relose_type='解挂'
go

