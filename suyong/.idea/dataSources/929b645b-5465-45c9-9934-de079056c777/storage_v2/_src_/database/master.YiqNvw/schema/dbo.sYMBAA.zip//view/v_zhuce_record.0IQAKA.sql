create view v_zhuce_record
as
select Id_num  账号,  Zhuce_time 注册时间,  Id_pop 经办人
from zhuce_record
go

