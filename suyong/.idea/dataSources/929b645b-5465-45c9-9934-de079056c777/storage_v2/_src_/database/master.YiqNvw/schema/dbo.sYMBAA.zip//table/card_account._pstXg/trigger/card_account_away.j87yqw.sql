create trigger card_account_away
on card_account
    for update
as
	declare @newstatu varchar(50) ,@user varchar(50),@id int,@money int;
	select @user = card_account_user from inserted;
	select @newstatu = 账户状态,@id=卡号,@money =余额 from user_sum  where 账号= @user ;
	select @money  = card_account_money  from deleted 
	if(@newstatu ='注销')
		begin
			print '注销成功3！';
			update school_card  set school_card_statu='注销' where school_card_id = @id;
			insert into away_card (away_card_user) values(@user )
			if (@money !=0)
				print '注销返回余额！';
				begin
					insert into pay_card (pay_card_user,pay_card_money,pay_card_cause ) values(@user ,@money,'注销退还余额')
				end
		end
	else
		print '注销失败3！';

go

