create trigger school_card_statu_update
on school_card
    for update
as
    declare @oldstatue varchar(20),@newstatue varchar(20), @oldid int,@newid int ;
    --更新前的数据
    select @oldstatue = school_card_statu from deleted;
	select @newstatue = school_card_statu from inserted
	select @oldid = school_card_id from deleted;
	--print @oldstatue;
	--print @newstatue;
	if (@oldstatue='挂失'and @newstatue='补办')
		begin
		--更新后的数据
			print '补办成功！';
			insert into school_card values('正常使用');
			select @newid = max(school_card_id) from school_card;
			update card_account set card_account_id=@newid where card_account_id=@oldid;
		end
	else
		print '补办失败！';
go

