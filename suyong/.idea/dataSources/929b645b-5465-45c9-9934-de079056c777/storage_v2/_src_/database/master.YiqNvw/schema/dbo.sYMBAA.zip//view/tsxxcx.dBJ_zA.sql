create view tsxxcx as
select book_id 书本ID,book_name 书本名称,book_type 书本类型,book_status 书本状态 from book_id
go

