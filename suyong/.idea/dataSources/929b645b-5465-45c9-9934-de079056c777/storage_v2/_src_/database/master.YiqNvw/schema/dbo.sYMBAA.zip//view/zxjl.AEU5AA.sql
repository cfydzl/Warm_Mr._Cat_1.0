create view zxjl as
select away_card_user 账号,away_card_cause 事由,away_card_time 时间,away_card_opt 经办人 from away_card
go

