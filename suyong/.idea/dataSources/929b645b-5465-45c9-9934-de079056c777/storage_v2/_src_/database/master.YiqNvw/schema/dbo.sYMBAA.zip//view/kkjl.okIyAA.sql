create view kkjl as
select pay_card_user 账号,pay_card_money 金额,pay_card_opt 经办人,pay_card_cause 事由,pay_card_time 时间 from pay_card
go

