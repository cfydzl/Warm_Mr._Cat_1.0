create view v_chongzhi_record
as
select  Id_num 账号,  Chong_time 充值时间, Chong_sum 充值金额,Id_pop 经办人
from chongzhi_record
go

