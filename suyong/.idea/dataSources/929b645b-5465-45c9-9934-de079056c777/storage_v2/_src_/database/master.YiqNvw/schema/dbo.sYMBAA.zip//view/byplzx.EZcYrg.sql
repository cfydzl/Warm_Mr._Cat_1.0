create view byplzx as
select card_account_user 账号,card_account_name 名字,card_account_id 卡号,card_account_money 余额,card_account_statu 状态,school_card_statu 卡状态 from card_account,school_card
where card_account_id=school_card_id
go

