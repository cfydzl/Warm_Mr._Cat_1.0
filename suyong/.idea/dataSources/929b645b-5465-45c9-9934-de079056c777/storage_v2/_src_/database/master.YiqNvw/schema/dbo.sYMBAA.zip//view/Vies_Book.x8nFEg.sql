create view Vies_Book
as
	select b.Bid,b.Bname,b.Bpress,b.Bspecies,a.num from Book b,(select Bname,count(Bname)num from Book where (Book.Buser='') group by Bname ) a where(a.Bname=b.Bname and b.Buser=' ')

go

