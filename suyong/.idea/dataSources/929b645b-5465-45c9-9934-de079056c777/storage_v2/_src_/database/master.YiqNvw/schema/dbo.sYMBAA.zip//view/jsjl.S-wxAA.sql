create view jsjl as
select borrow_book_user 账号,borrow_book_id 书本ID,borrow_book_time 时间 from borrow_book
go

