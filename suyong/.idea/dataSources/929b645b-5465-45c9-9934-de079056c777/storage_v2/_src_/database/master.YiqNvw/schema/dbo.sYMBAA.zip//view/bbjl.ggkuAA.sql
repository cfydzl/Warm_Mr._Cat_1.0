create view bbjl as
select reward_card_user 账号,reward_card_oldid 旧卡号,reward_card_newid 新卡号, reward_card_time 时间,reward_card_opt 经办人 from reward_card
go

