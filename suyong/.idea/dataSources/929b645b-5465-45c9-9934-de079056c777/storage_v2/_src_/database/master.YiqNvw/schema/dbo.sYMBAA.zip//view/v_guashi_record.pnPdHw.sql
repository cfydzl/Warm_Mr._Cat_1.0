create view v_guashi_record
as
select  Id_num 账号,  Gua_time 挂失时间, Id_pop 经办人
from guashi_record
go

