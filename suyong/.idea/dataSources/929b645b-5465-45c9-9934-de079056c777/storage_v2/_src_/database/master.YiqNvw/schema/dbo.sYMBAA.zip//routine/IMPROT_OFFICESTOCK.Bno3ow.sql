


--用品类别导入
CREATE PROCEDURE [dbo].[IMPROT_OFFICESTOCK]  
AS 
   BEGIN
      -- 定义存储过程变量 --
      DECLARE
         @lc$PRODUCTSREGISTRATIONID varchar(32), 
         @lc$PRODUCTSCATEGORYID varchar(32), 
         @lc$PRODUCTSCODE varchar(100), 
         @lc$PRODUCTSNAME varchar(120), 
         @lc$SPECIFICATIONS varchar(128), 
         @lc$UNIT varchar(128), 
         @lc$PRODUCTSNUMBER numeric(38, 0), 
         @lc$REMARK varchar(255), 
         @lc$CREATED varchar(32), 
         @lc$CREATEDATE char(19), 
         @lc$CREATELOGO numeric(38, 0), 
         @lc$VERSIONID varchar(32), 
         @lc$VERSIONCODE numeric(38, 0), 
         @lc$BUSINESSSORTING numeric(38, 0), 
         @lc$ORGANIZATIONALLEVELCODE varchar(60), 
         @lc$AGENCYCODE varchar(60), 
         @lc$PREPAREFIELD0 varchar(100), 
         @lc$PREPAREFIELD1 varchar(100), 
         @lc$PREPAREFIELD2 varchar(100), 
         @lc$MATERIALCHARACTOR varchar(60), 
         @lc$CONFIRMSTATE numeric(38, 0), 
         @lc$PHOTONAMES varchar(255), 
         @lc$COMM_APPID varchar(50)
   
	    -- 定义游标并赋值 --
      DECLARE
          c CURSOR LOCAL FORWARD_ONLY FOR 
            SELECT 
               t.PRODUCTSREGISTRATIONID, 
               t.PRODUCTSCATEGORYID, 
               t.PRODUCTSCODE, 
               t.PRODUCTSNAME, 
               t.SPECIFICATIONS, 
               t.UNIT, 
               t.PRODUCTSNUMBER, 
               t.REMARK, 
               t.CREATED, 
               t.CREATEDATE, 
               t.CREATELOGO, 
               t.VERSIONID, 
               t.VERSIONCODE, 
               t.BUSINESSSORTING, 
               t.ORGANIZATIONALLEVELCODE, 
               t.AGENCYCODE, 
               t.PREPAREFIELD0, 
               t.PREPAREFIELD1, 
               t.PREPAREFIELD2, 
               t.MATERIALCHARACTOR, 
               t.CONFIRMSTATE, 
               t.PHOTONAMES, 
               t.COMM_APPID
            FROM dbo.TBL_OFFICE_USAGE_STOCK_TEMP  AS t 
			where t.PRODUCTSCODE not in (select PRODUCTSCODE from TBL_OFFICE_USAGE_STOCK where CREATELOGO='0')

      OPEN c

      WHILE 1=1
      
         BEGIN

            FETCH c
                INTO 
                  @lc$PRODUCTSREGISTRATIONID, 
                  @lc$PRODUCTSCATEGORYID, 
                  @lc$PRODUCTSCODE, 
                  @lc$PRODUCTSNAME, 
                  @lc$SPECIFICATIONS, 
                  @lc$UNIT, 
                  @lc$PRODUCTSNUMBER, 
                  @lc$REMARK, 
                  @lc$CREATED, 
                  @lc$CREATEDATE, 
                  @lc$CREATELOGO, 
                  @lc$VERSIONID, 
                  @lc$VERSIONCODE, 
                  @lc$BUSINESSSORTING, 
                  @lc$ORGANIZATIONALLEVELCODE, 
                  @lc$AGENCYCODE, 
                  @lc$PREPAREFIELD0, 
                  @lc$PREPAREFIELD1, 
                  @lc$PREPAREFIELD2, 
                  @lc$MATERIALCHARACTOR, 
                  @lc$CONFIRMSTATE, 
                  @lc$PHOTONAMES, 
                  @lc$COMM_APPID

            IF @@FETCH_STATUS = -1
               BREAK

            INSERT dbo.TBL_OFFICE_USAGE_STOCK(
               PRODUCTSREGISTRATIONID, 
               PRODUCTSCATEGORYID, 
               PRODUCTSCODE, 
               PRODUCTSNAME, 
               SPECIFICATIONS, 
               UNIT, 
               PRODUCTSNUMBER, 
               REMARK, 
               CREATED, 
               CREATEDATE, 
               CREATELOGO, 
               ORGANIZATIONALLEVELCODE, 
               AGENCYCODE, 
               MATERIALCHARACTOR)
               VALUES (
                  @lc$PRODUCTSREGISTRATIONID, 
                  
                     (
                        SELECT top 1 t.PRODUCTSCATEGORYID
                        FROM dbo.TBL_OFFICE_USAGE_TYPE  AS t
                        WHERE t.PRODUCTSCATEGORYNAME = @lc$PRODUCTSCATEGORYID  and CREATELOGO='1'
                     ), 
                  @lc$PRODUCTSCODE, 
                  @lc$PRODUCTSNAME, 
                  @lc$SPECIFICATIONS, 
                  @lc$UNIT, 
                  0, 
                  @lc$REMARK, 
                  
                     (
                        SELECT top 1 u.USER_ID
                        FROM dbo.TBL_SYS_USER  AS u
                        WHERE u.USER_NAME = @lc$CREATED AND COMM_RECORD_IDENTY IN (0,1)
                     ), 
                  
                     CASE @lc$CREATEDATE
                        WHEN NULL THEN CONVERT(varchar(100), GETDATE(), 20)
                        --ssma_oracle.to_char_date(sysdatetime(), 'yyyy-mm-dd HH:mi:ss')
                        ELSE @lc$CREATEDATE
                     END, 
                  '0', 
                  
                     (
                        SELECT top 1 u.COMM_ORG_LEVEL
                        FROM dbo.TBL_SYS_USER  AS u
                        WHERE u.USER_NAME = @lc$CREATED AND COMM_RECORD_IDENTY IN (0,1)
                     ), 
                  
                     (
                        SELECT top 1 u.COMM_ORG_IDENTY
                        FROM dbo.TBL_SYS_USER  AS u
                        WHERE u.USER_NAME = @lc$CREATED AND COMM_RECORD_IDENTY IN (0,1)
                     ), 
                  @lc$MATERIALCHARACTOR)  

         END

      CLOSE c

      DEALLOCATE c

   END
go

