create view v_koukuan_record
as
select Id_num  账号,  KouK_time 扣款时间,  Kouk_reas 扣款事由
from koukuan_record
go

