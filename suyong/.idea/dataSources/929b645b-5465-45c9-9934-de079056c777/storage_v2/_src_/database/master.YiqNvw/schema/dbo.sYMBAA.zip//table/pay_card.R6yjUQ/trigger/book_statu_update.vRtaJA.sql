create trigger book_statu_update
on pay_card
    for insert
as
	declare @user varchar(50),@opt varchar(50);
	select @user = pay_card_user,@opt=pay_card_opt from inserted ;
	if (@opt='图书扣款系统')
		begin
		print '图书信息更新成功'
			update pay_book set pay_book_status='已缴费' where pay_book_status='未缴费'and pay_book_user=@user
		end
	else
		print '图书信息无更新'

go

