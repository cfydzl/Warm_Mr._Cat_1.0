CREATE FUNCTION [dbo].[GET_CALENDAR_DIFF_DAYS] 
( 
   @calendarId varchar(32),
   @endtime datetime,
   @starttime datetime
)

RETURNS numeric
AS 
   BEGIN

      DECLARE
         @beginYear        INT, --开始日期的年份
     @endYear          INT, --结束日期的年份
         @beginMonth       INT, --开始日期的月份
     @endMonth         INT, --结束日期的年份
         @beginDay         INT, --开始日期的天
         @endDay           INT, --结束日期的天
     @diffDays         numeric
    if @endtime is null
    begin
      return 0
    end
      if @starttime is null 
    begin
      return 0
    end
     
    select @beginYear=Datepart(yyyy, @starttime) 
    select @endYear=Datepart(yyyy, @endtime)
    select @beginMonth=Datepart(mm, @starttime)
      select @endMonth=Datepart(mm, @endtime)
      select @beginDay=Datepart(dd, @starttime)
      select @endDay=Datepart(dd, @endtime)

      if @beginMonth < @endMonth 
    BEGIN
      select @diffDays = count(*) from TBL_CALENDAR_DETAIL where CALENDAR_ID = @calendarId 
                  and (((CALENDAR_MONTH > @beginMonth 
          and CALENDAR_MONTH < @endMonth) 
                  or (CALENDAR_MONTH = @beginMonth  
          and CALENDAR_day >= @beginDay)) 
          or (CALENDAR_MONTH = @endMonth 
          and CALENDAR_day <= @endDay )) 
          --order by CALENDAR_MONTH, CALENDAR_day
    END
    else 
     BEGIN
    select @diffDays=count(*) from TBL_CALENDAR_DETAIL where CALENDAR_ID = @calendarId 
                  and (((CALENDAR_MONTH > @beginMonth 
          and CALENDAR_MONTH < @endMonth) 
                  or (CALENDAR_MONTH = @beginMonth  
          and CALENDAR_day >= @beginDay)) 
          AND (CALENDAR_MONTH = @endMonth 
          and CALENDAR_day <= @endDay )) 
          --order by CALENDAR_MONTH, CALENDAR_day
     END
  
  RETURN @diffDays

   END
--GET_CALENDAR_DIFF_DAYS

--GET_CALENDAR_ID
go

