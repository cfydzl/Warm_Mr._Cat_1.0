
CREATE view vw_tbl_sys_dictionary_02
AS
select dict_id ,dict_name as dictname2 from tbl_sys_dictionary

go

