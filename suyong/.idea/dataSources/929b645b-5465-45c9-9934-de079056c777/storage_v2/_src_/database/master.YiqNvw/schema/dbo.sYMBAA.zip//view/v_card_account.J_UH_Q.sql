create view v_card_account
as
select Id_num  账号,  Id_name 姓名,  Id_card 卡号 ,  Id_sum 余额,  Id_Status1 账户状态, St_Status 用户状态
from card_account
go

