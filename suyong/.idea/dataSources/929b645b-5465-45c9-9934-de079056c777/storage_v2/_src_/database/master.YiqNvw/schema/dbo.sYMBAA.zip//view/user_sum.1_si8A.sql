create view user_sum as
select ca.card_account_user 账号,cp.card_passward_passward 密码,ca.card_account_id 卡号,ca.card_account_name 名字,ca.card_account_statu 账户状态,sc.school_card_statu 一卡通状态,ca.card_account_money 余额
from school_card as sc,card_account as ca,card_passward as cp 
where sc.school_card_id =ca.card_account_id and ca.card_account_user=cp.card_passward_user;
go

