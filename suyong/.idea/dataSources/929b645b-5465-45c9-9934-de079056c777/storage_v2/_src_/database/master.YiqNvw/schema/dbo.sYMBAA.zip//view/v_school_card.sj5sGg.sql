create view v_school_card
as
select Id_card  卡号,  Id_status 卡状态
from school_card
go

