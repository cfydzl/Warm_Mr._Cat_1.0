create view books_statu as
select borrow_book_user 账号,borrow_book_id 书本ID,borrow_book_time 借阅时间, book_status 状态
from borrow_book ,book_id where borrow_book_id=book_id and book_status='在借'
go

