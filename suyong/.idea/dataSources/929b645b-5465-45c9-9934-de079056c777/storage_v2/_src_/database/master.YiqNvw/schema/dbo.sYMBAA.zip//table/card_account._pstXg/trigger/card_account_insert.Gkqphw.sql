create trigger card_account_insert
on card_account
    for insert
as
	declare @newid int ,@user varchar(50);
	select @user = card_account_user from inserted;
	insert into school_card values('正常使用');
	select @newid = max(school_card_id) from school_card;
	update card_account set card_account_id=@newid where card_account_user= @user;
	insert register_card(register_card_user) values(@user)
	print '插入触发器'
go

