create view zcjl as
select register_card_user 账号,register_card_time 时间,register_card_opt 经办人 from register_card
go

