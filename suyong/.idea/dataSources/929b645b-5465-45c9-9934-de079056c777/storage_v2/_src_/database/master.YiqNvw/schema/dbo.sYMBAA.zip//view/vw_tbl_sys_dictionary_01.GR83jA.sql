--用品管理 
CREATE view vw_tbl_sys_dictionary_01
AS
select dict_id ,dict_name as dictname1 from tbl_sys_dictionary

go

