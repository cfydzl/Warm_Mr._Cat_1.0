create trigger book_id_update
on book_id
    for update
as
	declare @oldstute varchar(50) ,@id varchar(50),@user varchar(50),@time datetime,@span int;
	select @oldstute = book_status,@id=book_id from deleted ;
	select @user = borrow_book_user,@time=borrow_book_time from borrow_book where borrow_book_id=@id and borrow_book_time=(select max(borrow_book_time) from borrow_book where borrow_book_id=@id);
	print @oldstute;
	if(@oldstute  ='未借')
		begin
			print '还书成功4！';
			insert into borrow_book (borrow_book_id) values(@id)
		end
	else if (@oldstute  ='在借')
		begin
			insert into return_book (return_book_id,return_book_user) values(@id,@user)
			SELECT @span =DATEDIFF ( day, @time,getdate() )
			if (@span>30)
				begin
					insert into pay_book(pay_book_user,pay_book_money,pay_book_type,pay_book_day)values(@user,1*@span,@id+'图书超期',@span);
					print '图书逾期';
				end
			else
				print '图书未逾期！';
		end
	else
		print '还书失败3！';
go

