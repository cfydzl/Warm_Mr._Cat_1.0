create view jhjl as
select card_activate_user 账号,card_activate_time 时间  from card_activate
go

