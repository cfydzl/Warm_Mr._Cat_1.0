--2018-03-20 个人财务查询联合查询使用 end

--2018-03-20  培训成绩统计视图 start
CREATE VIEW V_TRAIN_EXAM_MANAGE (
   CASSIFIED_ID, 
   CASSIFIED_NAME, 
   TRAIN_NAME, 
   PAPER_NAME, 
   DEPT_NAME, 
   COUNT_USER, 
   COUNT_PASS_USER, 
   PASS_RATE, 
   AVG_SCORE, 
   IS_FINISH)
AS 
    (
      SELECT 
         w.CASSIFIED_ID AS cassified_id, 
         w.CASSIFIED_NAME AS cassified_name, 
         t.TRAIN_NAME AS train_name, 
         a.PAPER_NAME AS paper_name, 
         i.DEPT_NAME AS dept_name, 
         count_big(b.PAPER_ID) AS count_user, 
         sum(
            CASE 
               WHEN b.SCORE >= a.PASS_SCORE THEN 1
               ELSE 0
            END) AS count_pass_user, 
         CASE 
            WHEN count_big(b.PAPER_ID) > 0 THEN round(sum(
               CASE 
                  WHEN b.SCORE >= a.PASS_SCORE THEN 1
                  ELSE 0
               END) * 100.00 / count_big(b.PAPER_ID), 2)
            ELSE 0
         END AS pass_rate, 
         CASE 
            WHEN avg(CAST(b.SCORE AS float(53))) > 0 THEN round(avg(CAST(b.SCORE AS float(53))), 2)
            ELSE 0
         END AS avg_score, 
         b.IS_FINISH AS is_finish
      FROM 
         dbo.TBL_TRAIN_EXAMPAPER  AS a 
            LEFT JOIN dbo.TBL_TRAIN_ONLINE_EXAM  AS b 
            ON a.PAPER_ID = b.PAPER_ID 
            LEFT JOIN dbo.TBL_TRAIN_MANAGE  AS t 
            ON t.TRAIN_ID = a.TRAIN_ID 
            LEFT JOIN dbo.TBL_TRAIN_CASSIFIED  AS w 
            ON w.CASSIFIED_ID = t.CASSIFIED_ID 
            LEFT JOIN dbo.TBL_SYS_USER  AS h 
            ON h.USER_ID = b.USER_ID 
            LEFT JOIN dbo.TBL_SYS_DEPARTMENT  AS i 
            ON i.DEPT_ID = h.DEPT_ID
      WHERE 
         a.PAPER_NAME IS NOT NULL AND 
         t.TRAIN_NAME IS NOT NULL AND 
         b.IS_FINISH = 1 AND 
         w.CASSIFIED_NAME IS NOT NULL AND 
         i.DEPT_NAME IS NOT NULL
      GROUP BY 
         w.CASSIFIED_ID, 
         w.CASSIFIED_NAME, 
         a.PAPER_NAME, 
         t.TRAIN_NAME, 
         i.DEPT_NAME, 
         b.IS_FINISH
    );
go

