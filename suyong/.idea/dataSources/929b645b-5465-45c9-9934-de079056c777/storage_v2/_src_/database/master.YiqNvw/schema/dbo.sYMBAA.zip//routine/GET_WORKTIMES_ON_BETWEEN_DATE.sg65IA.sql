-- =============================================
-- Author:		<zhangwd>
-- Create date: <2014-11-14>
-- Description:	<>
-- =============================================
CREATE FUNCTION [dbo].[GET_WORKTIMES_ON_BETWEEN_DATE]
(
	-- Add the parameters for the function here
	@userId VARCHAR(32),
    @endtime   DATETIME,
    @starttime DATETIME
)
RETURNS INT
AS
BEGIN
	-- Declare the return variable here
	DECLARE 
		@beginYear           INT, --开始日期的年份
		@endYear             INT, --结束日期的年份
		@beginMonth          INT, --开始日期的月份
		@endMonth            INT, ----结束日期的年份
		@beginDay            INT, --开始日期的天
		@endDay              INT, --结束日期的天
		@calendarId          VARCHAR(50), -- 日历id
		@diffDays            INT, -- 两个日期相差的天数
		@everyDayWorkTime    INT,
		@endDiffDays         INT, --跨年日期 结束年到结束的天数
		@endEveryDayWorkTime INT, --跨年日期 结束年每天的工作时间
		@endCalendarId       VARCHAR(50), -- 跨年日期 结束日历id
		@temp1               INT,
		@temp2               DATETIME,
		@temp3               DATETIME,
		@temp4               DATETIME,
		@temp5               INT,
		@temp6               INT,
		@temp7               DATETIME,
		@temp8               DATETIME,
		@temp9               DATETIME,
		@temp10              INT,
		@begin_time          VARCHAR(50),
		@end_time            VARCHAR(50),
		@totalTime           INT

	-- Add the T-SQL statements to compute the return value here
	select @beginYear=Datepart(yyyy, @starttime) 
	select @endYear=Datepart(yyyy, @endtime)
	select @beginMonth=Datepart(mm, @starttime)
    select @endMonth=Datepart(mm, @endtime)
    select @beginDay=Datepart(dd, @starttime)
    select @endDay=Datepart(dd, @endtime)
	select @begin_time = convert(varchar(100), @starttime, 108)
	select @end_time = convert(varchar(100), @endtime, 108) 


	set @temp5 = 0
	set @temp10 = 0
	
	--不是跨年的算法
	if @endYear = @beginYear
	begin
		--获取日历id
		select @calendarId = dbo.get_calendar_id(@endYear, @userId)
		--获取两个日期相差的天数
		select @diffDays = dbo.get_calendar_diff_days(@calendarId, @endtime, @starttime)
		
		--获取每天的工作时间
		select @everyDayWorkTime = Datediff(second,
                convert(datetime, '2000-01-01 ' + work_time + ':00'), 
                convert(datetime,'2000-01-01 ' + closed_time + ':00'))
		from TBL_CALENDAR
		where calendar_id = @calendarId
		--返回相差天数与每天的工作时间 是秒级别的
		select @totalTime = @diffDays * @everyDayWorkTime
	end
	else
	begin
		--获取开始年的calendarId
		select @calendarId = dbo.get_calendar_id(@beginYear, @userId)
		--执行天数查询 将值赋给diffDays
		select @diffDays = dbo.get_calendar_diff_days(@calendarId,
                                       convert(datetime, cast(@beginYear as varchar) + '-12-31'),
                                       @starttime);
		--获取开始年每天的工作时间
		select @everyDayWorkTime = Datediff(second,
                convert(datetime, '2000-01-01 ' + work_time + ':00'), 
                convert(datetime, '2000-01-01 ' + closed_time + ':00'))
        from TBL_CALENDAR
		where calendar_id = @calendarId

		--获取结束年的calendarId
		select @endCalendarId = dbo.get_calendar_id(@endYear, @userId)
		select @endDiffDays = dbo.get_calendar_diff_days(@endCalendarId, @endtime,
                                            convert(datetime, cast(@endYear as varchar) + '-01-01'))
		--获取结束年每天的工作时间
		select @endEveryDayWorkTime = Datediff(second,
				convert(datetime, '2000-01-01 ' + work_time + ':00'),
				convert(datetime, '2000-01-01 ' + closed_time + ':00'))   
		from TBL_CALENDAR
		where calendar_id = @endCalendarId;
		--返回相差天数与每天的工作时间 是秒级别的
		set @totalTime = (@diffDays * @everyDayWorkTime ) + (@endDiffDays * @endEveryDayWorkTime)
	end
	
	--开始日期是否是工作日
	select @calendarId = dbo.get_calendar_id(@beginYear, @userId)
    select @temp1 = count(*) from TBL_CALENDAR_DETAIL
    where CALENDAR_ID = @calendarId and calendar_month = @beginMonth
       and calendar_day = @beginDay and CALENDAR_DATE_TYPE = 0
    if @temp1 > 0
    begin
		--开始时间
		select @temp2 = convert(datetime, '2000-01-01 ' + @begin_time)
		--下班时间
		select @temp3 = convert(datetime, '2000-01-01 ' + closed_time + ':00')
        from TBL_CALENDAR
		where calendar_id = @calendarId
		--上班时间
		select @temp4 = convert(datetime, '2000-01-01 ' + work_time + ':00')
        from TBL_CALENDAR
        where calendar_id = @calendarId
		--如果开始时间大于下班时间则返回0
		if @temp2 >= @temp3
		begin
			set @temp5 = 0
		end
		else
		begin
			if @temp2 > @temp4 --如果开始时间比上班时间晚 则下班时间减开始时间
			begin
				select @temp5 = Datediff(second, 
					convert(datetime, '2000-01-01 ' + @begin_time),
					convert(datetime, '2000-01-01 ' + closed_time + ':00'))					    
				from TBL_CALENDAR
				where calendar_id = @calendarId
			end
			else -- 如果开始时间比上班时间早则下班时间减上班时间
			begin
				set @temp5 = @everyDayWorkTime
			end
		end
		--开始时间为工作日时减去
		set @temp5 = @everyDayWorkTime - @temp5
    end
    
    select @endCalendarId = dbo.get_calendar_id(@endYear, @userId)
    select @temp6 = count(*) from TBL_CALENDAR_DETAIL
    where CALENDAR_ID = @endCalendarId
       and calendar_month = @endMonth
       and calendar_day = @endDay
       and CALENDAR_DATE_TYPE = 0
    
    if @temp6 > 0 --结束日期是否是工作日
    begin
        if @endEveryDayWorkTime is null
		begin
			set @endEveryDayWorkTime = @everyDayWorkTime
		end
		--结束时间
		select @temp7 = convert(datetime, '2000-01-01 ' + @end_time);
		--下班时间
		select @temp8 = convert(datetime, '2000-01-01 ' + closed_time + ':00')
        from TBL_CALENDAR
        where calendar_id = @endCalendarId
		--上班时间
		select @temp9 = convert(datetime, '2000-01-01 ' + work_time + ':00')
        from TBL_CALENDAR
        where calendar_id = @endCalendarId
		if @temp7 < @temp9 --在上班时间之前结束，工作时间为0
		begin
			set @temp10 = 0
		end
		else
		begin
			if @temp7 < @temp8 --在上班时间和下班时间之间结束
			begin
				select @temp10 = Datediff(second, 
					convert(datetime, '2000-01-01 ' + work_time + ':00'),
					convert(datetime, '2000-01-01 ' + @end_time ))
				from TBL_CALENDAR
				where calendar_id = @endCalendarId
			end
			else --在下班之后离开
			begin
				set @temp10 = @endEveryDayWorkTime
			end
		end
		set @temp10 = @endEveryDayWorkTime - @temp10
	end
	-- Return the result of the function
	RETURN @totalTime - @temp5 - @temp10
END
--GET_WORKTIMES_ON_BETWEEN_DATE
go

