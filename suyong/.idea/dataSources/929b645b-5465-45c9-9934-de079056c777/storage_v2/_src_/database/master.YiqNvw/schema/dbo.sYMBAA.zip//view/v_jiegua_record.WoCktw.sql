create view v_jiegua_record
as
select  Id_num 账号,  Jie_time 解挂时间, Id_pop 经办人
from jiegua_record
go

