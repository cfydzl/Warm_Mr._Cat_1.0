create trigger card_activate_update
on card_activate
    for insert
as
	declare @user varchar(50),@id int;
	select @user = card_activate_user from inserted;
	select @id = 卡号 from user_sum where 账号 =@user
	update school_card set school_card_statu='正常使用' where school_card_id=@id
go

